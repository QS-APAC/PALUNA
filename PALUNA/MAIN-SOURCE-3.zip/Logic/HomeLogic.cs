﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PALUNA.Logic
{
    public class HomeLogic
    {
    }
}